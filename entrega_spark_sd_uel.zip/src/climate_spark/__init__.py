"""PySpark climate analysis package."""

